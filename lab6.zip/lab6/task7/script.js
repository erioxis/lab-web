'use strict';

const loadProfileBtn = document.getElementById('loadProfileBtn');
const currentProfileDiv = document.getElementById('currentProfile');
const profileCountSpan = document.getElementById('profileCount');

const PROFILE_STORAGE_KEY = 'userProfiles';

function getFormattedDateTime() {
    const now = new Date();
    return now.toLocaleString('ru-RU', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

function updateProfileCount() {
    const profiles = JSON.parse(localStorage.getItem(PROFILE_STORAGE_KEY)) || [];
    profileCountSpan.textContent = profiles.length;
}

function displayCurrentProfile(userData) {
    currentProfileDiv.innerHTML = '';

    const img = document.createElement('img');
    img.src = userData.picture.large;
    img.alt = 'Фото профиля';
    img.className = 'profile-image';

    const infoDiv = document.createElement('div');
    infoDiv.className = 'profile-info';

    const nameP = document.createElement('p');
    nameP.innerHTML = `<strong>Имя:</strong> ${userData.name.title} ${userData.name.first} ${userData.name.last}`;

    const emailP = document.createElement('p');
    emailP.innerHTML = `<strong>Email:</strong> ${userData.email}`;

    const locationP = document.createElement('p');
    locationP.innerHTML = `<strong>Местоположение:</strong> ${userData.location.city}, ${userData.location.country}`;

    const genderP = document.createElement('p');
    genderP.innerHTML = `<strong>Пол:</strong> ${userData.gender === 'male' ? 'Мужской' : 'Женский'}`;

    const dobP = document.createElement('p');
    const dob = new Date(userData.dob.date);
    const formattedDob = dob.toLocaleDateString('ru-RU');
    dobP.innerHTML = `<strong>Дата рождения:</strong> ${formattedDob} (Возраст: ${userData.dob.age})`;

    const registeredP = document.createElement('p');
    const registered = new Date(userData.registered.date);
    const formattedRegistered = registered.toLocaleDateString('ru-RU');
    registeredP.innerHTML = `<strong>Дата регистрации:</strong> ${formattedRegistered}`;

    infoDiv.appendChild(nameP);
    infoDiv.appendChild(emailP);
    infoDiv.appendChild(locationP);
    infoDiv.appendChild(genderP);
    infoDiv.appendChild(dobP);
    infoDiv.appendChild(registeredP);

    currentProfileDiv.appendChild(img);
    currentProfileDiv.appendChild(infoDiv);
}

async function loadUserProfile() {
    try {
        const response = await fetch('https://randomuser.me/api/');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        const user = data.results[0];

        displayCurrentProfile(user);

        const profiles = JSON.parse(localStorage.getItem(PROFILE_STORAGE_KEY)) || [];
        profiles.push({
            ...user,
            savedAt: getFormattedDateTime()
        });
        localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profiles));

        updateProfileCount();

    } catch (err) {
        console.error("Проблема с fetch:", err);
        currentProfileDiv.innerHTML = '<div class="error">Не удалось загрузить профиль</div>';
    }
}

loadProfileBtn.addEventListener('click', loadUserProfile);

document.addEventListener('DOMContentLoaded', updateProfileCount);