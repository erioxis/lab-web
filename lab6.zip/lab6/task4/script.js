'use strict';

const HISTORY_STORAGE_KEY = 'visitHistory';
const MAX_HISTORY_LENGTH = 5;

function getFormattedDateTime() {
    const now = new Date();
    return now.toLocaleString('ru-RU', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

function saveVisitToHistory() {
    const history = JSON.parse(localStorage.getItem(HISTORY_STORAGE_KEY)) || [];
    const newVisit = {
        date: getFormattedDateTime(),
        timestamp: Date.now()
    };

    history.unshift(newVisit);

    if (history.length > MAX_HISTORY_LENGTH) {
        history.length = MAX_HISTORY_LENGTH;
    }

    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history));
}

function loadAndDisplayHistory() {
    const history = JSON.parse(localStorage.getItem(HISTORY_STORAGE_KEY)) || [];
    const historyList = document.getElementById('historyList');

    historyList.innerHTML = '';

    if (history.length === 0) {
        const noHistoryItem = document.createElement('li');
        noHistoryItem.className = 'no-history';
        noHistoryItem.textContent = 'История посещений пуста';
        historyList.appendChild(noHistoryItem);
        return;
    }

    history.forEach((visit, index) => {
        const item = document.createElement('li');
        item.className = 'history-item';

        const dateSpan = document.createElement('span');
        dateSpan.className = 'history-date';
        dateSpan.textContent = visit.date;

        const indexSpan = document.createElement('span');
        indexSpan.className = 'history-index';
        indexSpan.textContent = `#${index + 1}`;

        item.appendChild(dateSpan);
        item.appendChild(indexSpan);

        historyList.appendChild(item);
    });
}

function clearHistory() {
    if (confirm('Вы уверены, что хотите очистить историю посещений?')) {
        localStorage.removeItem(HISTORY_STORAGE_KEY);
        loadAndDisplayHistory();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    saveVisitToHistory();
    loadAndDisplayHistory();

    const clearBtn = document.getElementById('clearHistoryBtn');
    clearBtn.addEventListener('click', clearHistory);
});