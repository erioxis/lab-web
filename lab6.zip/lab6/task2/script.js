'use strict';

const loader = document.getElementById('loader');
const weatherDataContainer = document.getElementById('weatherData');
const errorContainer = document.getElementById('error');
const cityNameEl = document.getElementById('cityName');
const temperatureEl = document.getElementById('temperature');
const descriptionEl = document.getElementById('description');
const cityInput = document.getElementById('cityInput');
const getWeatherBtn = document.getElementById('getWeatherBtn');
const cookieConsentDiv = document.getElementById('cookieConsent');
const weatherIcon = document.getElementById('weatherIcon');

function checkCookieConsent() {
    const consent = getCookie('weatherCookieConsent');
    if (consent === 'true' || consent === 'false') {
        cookieConsentDiv.style.display = 'none';
        if (consent === 'true') {
            const savedCity = getCookie('weatherCity');
            if (savedCity) {
                cityInput.value = decodeURIComponent(savedCity);
            }
        }
        return consent === 'true';
    }
    return null;
}

function setCookieConsent(consent) {
    const date = new Date();
    date.setTime(date.getTime() + (30 * 24 * 60 * 60 * 1000));
    document.cookie = `weatherCookieConsent=${consent}; expires=${date.toUTCString()}; path=/`;

    if (consent) {
        saveCityToCookie(cityInput.value);
    } else {
        removeCookie('weatherCity');
    }

    cookieConsentDiv.style.display = 'none';
}

function saveCityToCookie(city) {
    const consent = getCookie('weatherCookieConsent');
    if (consent === 'true') {
        const date = new Date();
        date.setTime(date.getTime() + (30 * 24 * 60 * 60 * 1000));
        document.cookie = `weatherCity=${encodeURIComponent(city)}; expires=${date.toUTCString()}; path=/`;
    }
}

function removeCookie(name) {
    document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
}

function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split('; ');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function setWeatherIcon(description) {
    const desc = description.toLowerCase();
    if (desc.includes('sun') || desc.includes('clear')) {
        weatherIcon.textContent = '☀️';
    } else if (desc.includes('cloud') && desc.includes('sun')) {
        weatherIcon.textContent = '⛅';
    } else if (desc.includes('cloud')) {
        weatherIcon.textContent = '☁️';
    } else if (desc.includes('rain') || desc.includes('shower') || desc.includes('drizzle')) {
        weatherIcon.textContent = '🌧️';
    } else if (desc.includes('snow')) {
        weatherIcon.textContent = '❄️';
    } else if (desc.includes('storm') || desc.includes('thunder')) {
        weatherIcon.textContent = '⛈️';
    } else {
        weatherIcon.textContent = '🌤️';
    }
}

async function getWeather(city) {
    weatherDataContainer.style.display = 'none';
    errorContainer.textContent = '';
    loader.style.display = 'block';
    getWeatherBtn.disabled = true;

    const apiUrl = `https://wttr.in/${city}?format=j1`;

    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error(`Не удалось получить данные для города: ${city}`);
        }
        const data = await response.json();

        const cityName = data.nearest_area[0].areaName[0].value;
        const temperature = data.current_condition[0].temp_C;
        const description = data.current_condition[0].weatherDesc[0].value;

        cityNameEl.textContent = cityName;
        temperatureEl.textContent = temperature;
        descriptionEl.textContent = description;

        setWeatherIcon(description);

        weatherDataContainer.style.display = 'block';
    } catch (err) {
        errorContainer.textContent = `Ошибка: ${err.message}. Попробуйте другой город.`;
    } finally {
        loader.style.display = 'none';
        getWeatherBtn.disabled = false;
    }
}

getWeatherBtn.addEventListener('click', () => {
    const city = cityInput.value.trim();
    if (!city) {
        errorContainer.textContent = 'Пожалуйста, введите название города.';
        return;
    }
    const consent = getCookie('weatherCookieConsent');
    if (consent === 'true') {
        saveCityToCookie(city);
    }
    getWeather(city);
});

cityInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        getWeatherBtn.click();
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const consentGiven = checkCookieConsent();
    if (consentGiven === false) {
        const savedCity = getCookie('weatherCity');
        if (savedCity) {
            removeCookie('weatherCity');
        }
    }
    const initialCity = cityInput.value.trim() || 'Краснодар';
    getWeather(initialCity);
});