'use strict';

const taskInput = document.getElementById('taskInput');
const addTaskBtn = document.getElementById('addTaskBtn');
const randomTaskBtn = document.getElementById('randomTaskBtn');
const taskList = document.getElementById('taskList');

const TASKS_STORAGE_KEY = 'todoTasks';

function getFormattedDateTime() {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    return `${day}.${month}.${year} ${hours}:${minutes}:${seconds}`;
}

function saveTasksToLocalStorage() {
    const tasks = [];
    document.querySelectorAll('.task-item').forEach(item => {
        tasks.push({
            text: item.dataset.taskText,
            date: item.querySelector('.task-header').textContent
        });
    });
    localStorage.setItem(TASKS_STORAGE_KEY, JSON.stringify(tasks));
}

function loadTasksFromLocalStorage() {
    const tasksJSON = localStorage.getItem(TASKS_STORAGE_KEY);
    if (tasksJSON) {
        try {
            const tasks = JSON.parse(tasksJSON);
            taskList.innerHTML = '';
            tasks.forEach(task => {
                const taskElement = createTaskElement(task.text);
                taskElement.querySelector('.task-header').textContent = task.date;
                taskList.appendChild(taskElement);
            });
        } catch (e) {
            console.error('Ошибка при загрузке задач из localStorage:', e);
        }
    }
}

function createTaskElement(text) {
    const item = document.createElement('div');
    item.className = 'task-item';
    item.dataset.taskText = text;

    const header = document.createElement('div');
    header.className = 'task-header';
    header.textContent = getFormattedDateTime();

    const taskText = document.createElement('div');
    taskText.className = 'task-text';
    taskText.textContent = text;

    const buttonsDiv = document.createElement('div');
    buttonsDiv.className = 'task-buttons';

    const copyBtn = document.createElement('button');
    copyBtn.className = 'task-button';
    copyBtn.textContent = 'Копировать';

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'task-button delete';
    deleteBtn.textContent = 'Удалить';

    buttonsDiv.appendChild(copyBtn);
    buttonsDiv.appendChild(deleteBtn);

    item.appendChild(header);
    item.appendChild(taskText);
    item.appendChild(buttonsDiv);

    copyBtn.addEventListener('click', () => {
        const taskDiv = copyBtn.closest('.task-item');
        const textToCopy = taskDiv.dataset.taskText;
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(textToCopy)
                .then(() => {
                    const originalText = copyBtn.textContent;
                    copyBtn.textContent = 'Скопировано!';
                    setTimeout(() => {
                        copyBtn.textContent = originalText;
                    }, 1000);
                })
                .catch(() => {
                    copyUsingExecCommand(textToCopy, copyBtn);
                });
        } else {
            copyUsingExecCommand(textToCopy, copyBtn);
        }
    });

    function copyUsingExecCommand(text, button) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        try {
            if (document.execCommand('copy')) {
                const originalText = button.textContent;
                button.textContent = 'Скопировано!';
                setTimeout(() => {
                    button.textContent = originalText;
                }, 1000);
            }
        } catch (e) {
            console.error('Ошибка копирования: ', e);
        }
        document.body.removeChild(textarea);
    }

    deleteBtn.addEventListener('click', () => {
        taskList.removeChild(item);
        saveTasksToLocalStorage();
        if (taskList.children.length === 0) {
            showEmptyMessage();
        }
    });

    return item;
}

function showEmptyMessage() {
    const emptyMsg = document.createElement('div');
    emptyMsg.className = 'empty-message';
    emptyMsg.textContent = 'Список задач пуст';
    taskList.appendChild(emptyMsg);
}

addTaskBtn.addEventListener('click', () => {
    const text = taskInput.value.trim();
    if (text) {
        // Убираем сообщение "список пуст" если оно есть
        const emptyMsg = taskList.querySelector('.empty-message');
        if (emptyMsg) {
            taskList.removeChild(emptyMsg);
        }
        
        const taskElement = createTaskElement(text);
        taskList.insertBefore(taskElement, taskList.firstChild);
        taskInput.value = '';
        saveTasksToLocalStorage();
    }
});

randomTaskBtn.addEventListener('click', () => {
    if (randomTasks && randomTasks.length > 0) {
        const emptyMsg = taskList.querySelector('.empty-message');
        if (emptyMsg) {
            taskList.removeChild(emptyMsg);
        }
        
        const randomIndex = Math.floor(Math.random() * randomTasks.length);
        const randomTask = randomTasks[randomIndex];
        const taskElement = createTaskElement(randomTask);
        taskList.insertBefore(taskElement, taskList.firstChild);
        saveTasksToLocalStorage();
    }
});

taskInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        addTaskBtn.click();
    }
});

document.addEventListener('DOMContentLoaded', () => {
    loadTasksFromLocalStorage();
});

window.addEventListener('beforeunload', () => {
    saveTasksToLocalStorage();
});