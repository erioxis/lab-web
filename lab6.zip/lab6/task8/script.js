'use strict';

const cityInput = document.getElementById('cityInput');
const getWeatherBtn = document.getElementById('getWeatherBtn');
const loader = document.getElementById('loader');
const weatherDataDiv = document.getElementById('weatherData');
const cityNameSpan = document.getElementById('cityName');
const temperatureSpan = document.getElementById('temperature');
const descriptionSpan = document.getElementById('description');
const windSpeedSpan = document.getElementById('windSpeed');
const windDirectionSpan = document.getElementById('windDirection');
const sourceSpan = document.getElementById('source');
const errorDiv = document.getElementById('error');
const weatherIcon = document.getElementById('weatherIcon');

const WEATHER_STORAGE_KEY = 'cachedWeatherData';
const LAST_CITY_KEY = 'lastRequestedCity';
const CACHE_DURATION = 10 * 60 * 1000;

function getFormattedDateTime() {
    const now = new Date();
    return now.toLocaleString('ru-RU', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

function degToCompass(deg) {
    const dirs = ['С', 'СВ', 'В', 'ЮВ', 'Ю', 'ЮЗ', 'З', 'СЗ'];
    const index = Math.round(deg / 45) % 8;
    return dirs[index];
}

function setWeatherIcon(description) {
    const desc = description.toLowerCase();
    if (desc.includes('ясно') || desc.includes('солнечно') || desc.includes('clear')) {
        weatherIcon.textContent = '☀️';
    } else if (desc.includes('облачно') && (desc.includes('небольшая') || desc.includes('partly'))) {
        weatherIcon.textContent = '⛅';
    } else if (desc.includes('облачно') || desc.includes('пасмурно') || desc.includes('cloud')) {
        weatherIcon.textContent = '☁️';
    } else if (desc.includes('дождь') || desc.includes('ливень') || desc.includes('rain')) {
        weatherIcon.textContent = '🌧️';
    } else if (desc.includes('снег') || desc.includes('snow')) {
        weatherIcon.textContent = '❄️';
    } else if (desc.includes('гроза') || desc.includes('шторм') || desc.includes('storm') || desc.includes('thunder')) {
        weatherIcon.textContent = '⛈️';
    } else if (desc.includes('туман') || desc.includes('fog') || desc.includes('mist')) {
        weatherIcon.textContent = '🌫️';
    } else {
        weatherIcon.textContent = '🌤️';
    }
}

function cacheWeatherData(city, data) {
    const cache = JSON.parse(localStorage.getItem(WEATHER_STORAGE_KEY)) || {};
    cache[city.toLowerCase()] = {
        data,
        timestamp: Date.now()
    };
    localStorage.setItem(WEATHER_STORAGE_KEY, JSON.stringify(cache));
    
    // Сохраняем последний запрошенный город
    localStorage.setItem(LAST_CITY_KEY, city);
}

function getCachedWeatherData(city) {
    const cache = JSON.parse(localStorage.getItem(WEATHER_STORAGE_KEY)) || {};
    const cached = cache[city.toLowerCase()];
    if (cached && (Date.now() - cached.timestamp) < CACHE_DURATION) {
        return cached.data;
    }
    return null;
}

function displayWeatherData(weatherData, source) {
    cityNameSpan.textContent = weatherData.name;
    temperatureSpan.textContent = weatherData.temp;
    descriptionSpan.textContent = weatherData.description;
    windSpeedSpan.textContent = weatherData.windSpeed;
    windDirectionSpan.textContent = degToCompass(weatherData.windDeg);
    sourceSpan.textContent = source;

    setWeatherIcon(weatherData.description);

    loader.style.display = 'none';
    weatherDataDiv.style.display = 'block';
    errorDiv.textContent = '';
}

async function fetchWeatherFromAPI(city) {
    try {
        // Используем wttr.in API
        const response = await fetch(`https://wttr.in/${encodeURIComponent(city)}?format=j1&lang=ru`);
        if (!response.ok) {
            if (response.status === 404) {
                throw new Error('Город не найден');
            }
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        
        if (!data.current_condition || data.current_condition.length === 0) {
            throw new Error('Данные о погоде не найдены');
        }

        const weather = data.current_condition[0];
        const area = data.nearest_area[0];
        
        return {
            name: area.areaName[0].value,
            temp: Math.round(parseInt(weather.temp_C)),
            description: weather.weatherDesc[0].value,
            windSpeed: (weather.windspeedKmph / 3.6).toFixed(1), // конвертируем км/ч в м/с
            windDeg: parseInt(weather.winddirDegree)
        };
    } catch (error) {
        console.error('API Error:', error);
        throw new Error('Не удалось получить данные о погоде. Проверьте название города.');
    }
}

async function getWeather(city) {
    loader.textContent = 'Загрузка данных о погоде...';
    loader.style.display = 'block';
    weatherDataDiv.style.display = 'none';
    errorDiv.textContent = '';
    getWeatherBtn.disabled = true;

    try {
        let weatherData = getCachedWeatherData(city);
        let source = '';

        if (weatherData) {
            source = 'localStorage (кэш)';
            displayWeatherData(weatherData, source);
        } else {
            weatherData = await fetchWeatherFromAPI(city);
            cacheWeatherData(city, weatherData);
            source = 'api wttr.in';
            displayWeatherData(weatherData, source);
        }

    } catch (err) {
        console.error("Проблема с fetch:", err);
        loader.style.display = 'none';
        weatherDataDiv.style.display = 'none';
        errorDiv.textContent = `Ошибка: ${err.message}`;
    } finally {
        getWeatherBtn.disabled = false;
    }
}

function loadLastCityWeather() {
    // Получаем последний запрошенный город
    const lastCity = localStorage.getItem(LAST_CITY_KEY);
    
    if (lastCity) {
        const cachedData = getCachedWeatherData(lastCity);
        if (cachedData) {
            // Если есть кэшированные данные для последнего города, показываем их
            cityInput.value = lastCity;
            displayWeatherData(cachedData, 'localStorage (кэш)');
        } else {
            // Если кэш устарел, но город сохранен, заполняем поле ввода
            cityInput.value = lastCity;
            loader.textContent = 'Введите город и нажмите кнопку';
        }
    } else {
        // Если нет сохраненного города, используем город по умолчанию
        const defaultCity = 'Москва';
        cityInput.value = defaultCity;
        loader.textContent = 'Введите город и нажмите кнопку';
    }
}

getWeatherBtn.addEventListener('click', () => {
    const city = cityInput.value.trim();
    if (!city) {
        errorDiv.textContent = 'Пожалуйста, введите название города.';
        return;
    }
    getWeather(city);
});

cityInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        getWeatherBtn.click();
    }
});

// Загружаем погоду для последнего города при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    loadLastCityWeather();
});

// Обработчик для очистки ошибки при вводе нового города
cityInput.addEventListener('input', () => {
    if (errorDiv.textContent) {
        errorDiv.textContent = '';
    }
});