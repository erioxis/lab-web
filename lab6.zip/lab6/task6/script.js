'use strict';

const form = document.getElementById('registrationForm');
const saveBtn = document.getElementById('saveBtn');
const submitBtn = document.getElementById('submitBtn');
const projectParticipationCheckbox = document.getElementById('projectParticipation');
const projectNameGroup = document.getElementById('projectNameGroup');
const projectNameInput = document.getElementById('projectName');
const beforeUnloadModal = document.getElementById('beforeUnloadModal');
const confirmLeaveBtn = document.getElementById('confirmLeaveBtn');
const cancelLeaveBtn = document.getElementById('cancelLeaveBtn');

const FORM_DATA_KEY = 'registrationFormData';

let hasUnsavedChanges = false;

// Функция для обновления видимости поля названия проекта
function updateProjectNameVisibility() {
    projectNameGroup.style.display = projectParticipationCheckbox.checked ? 'block' : 'none';
    // Не очищаем поле при скрытии, чтобы сохранить данные
}

projectParticipationCheckbox.addEventListener('change', () => {
    updateProjectNameVisibility();
    hasUnsavedChanges = true;
});

form.addEventListener('input', () => {
    hasUnsavedChanges = true;
});

form.addEventListener('change', () => {
    hasUnsavedChanges = true;
});

// Функция для получения данных формы
function getFormData() {
    const gender = document.querySelector('input[name="gender"]:checked');
    
    return {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        middleName: document.getElementById('middleName').value,
        gender: gender ? gender.value : '',
        faculty: document.getElementById('faculty').value,
        projectParticipation: projectParticipationCheckbox.checked,
        projectName: document.getElementById('projectName').value
    };
}

saveBtn.addEventListener('click', () => {
    const data = getFormData();
    
    // Валидация обязательных полей
    if (!data.firstName || !data.lastName || !data.middleName || !data.gender || !data.faculty) {
        alert('Пожалуйста, заполните все обязательные поля.');
        return;
    }

    if (data.projectParticipation && !data.projectName) {
        alert('Пожалуйста, укажите наименование проекта.');
        return;
    }
    
    localStorage.setItem(FORM_DATA_KEY, JSON.stringify(data));
    hasUnsavedChanges = false;
    alert('Данные успешно сохранены в localStorage!');
});

submitBtn.addEventListener('click', () => {
    const data = getFormData();

    if (!data.firstName || !data.lastName || !data.middleName || !data.gender || !data.faculty) {
        alert('Пожалуйста, заполните все обязательные поля.');
        return;
    }

    if (data.projectParticipation && !data.projectName) {
        alert('Пожалуйста, укажите наименование проекта.');
        return;
    }

    const tableRows = [];
    const fields = [
        { key: 'firstName', label: 'Имя' },
        { key: 'lastName', label: 'Фамилия' },
        { key: 'middleName', label: 'Отчество' },
        { key: 'gender', label: 'Пол', transform: (val) => val === 'male' ? 'Мужской' : 'Женский' },
        { key: 'faculty', label: 'Факультет' },
        { key: 'projectParticipation', label: 'Участие в проекте', transform: (val) => val ? 'Да' : 'Нет' },
        { key: 'projectName', label: 'Наименование проекта' }
    ];

    fields.forEach(field => {
        let value = data[field.key];
        if (field.transform) {
            value = field.transform(value);
        }
        // Показываем все поля, даже пустые
        tableRows.push(`<tr><td>${field.label}</td><td>${value || ''}</td></tr>`);
    });

    const tableHTML = `<table border="1" style="border-collapse: collapse; width: 100%; margin-top: 20px;">
        <thead><tr><th>Наименование поля</th><th>Значение поля</th></tr></thead>
        <tbody>${tableRows.join('')}</tbody>
    </table>`;

    const newWindow = window.open();
    newWindow.document.write(`
        <html>
            <head>
                <title>Результаты формы</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    table { margin: 20px auto; border-collapse: collapse; width: 80%; }
                    th, td { padding: 10px; border: 1px solid #ccc; text-align: left; }
                    th { background-color: #f2f2f2; font-weight: bold; }
                    h1 { color: #333; text-align: center; }
                </style>
            </head>
            <body>
                <h1>Данные формы регистрации</h1>
                ${tableHTML}
            </body>
        </html>
    `);
    newWindow.document.close();

    hasUnsavedChanges = false;
});

confirmLeaveBtn.addEventListener('click', () => {
    beforeUnloadModal.classList.remove('active');
    window.removeEventListener('beforeunload', preventLeave);
    window.location.reload();
});

cancelLeaveBtn.addEventListener('click', () => {
    beforeUnloadModal.classList.remove('active');
});

function preventLeave(e) {
    if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = '';
        beforeUnloadModal.classList.add('active');
        return '';
    }
}

window.addEventListener('beforeunload', preventLeave);

document.addEventListener('DOMContentLoaded', () => {
    const savedData = JSON.parse(localStorage.getItem(FORM_DATA_KEY));
    if (savedData) {
        console.log('Загруженные данные:', savedData); // Для отладки
        
        // Восстанавливаем текстовые поля и селекты
        if (savedData.firstName) document.getElementById('firstName').value = savedData.firstName;
        if (savedData.lastName) document.getElementById('lastName').value = savedData.lastName;
        if (savedData.middleName) document.getElementById('middleName').value = savedData.middleName;
        if (savedData.faculty) document.getElementById('faculty').value = savedData.faculty;
        
        // Восстанавливаем радиокнопки
        if (savedData.gender) {
            const genderRadio = document.querySelector(`input[name="gender"][value="${savedData.gender}"]`);
            if (genderRadio) {
                genderRadio.checked = true;
            }
        }
        
        // Восстанавливаем чекбокс участия в проекте и поле названия проекта
        if (savedData.projectParticipation !== undefined) {
            projectParticipationCheckbox.checked = Boolean(savedData.projectParticipation);
            if (savedData.projectName) {
                document.getElementById('projectName').value = savedData.projectName;
            }
            updateProjectNameVisibility();
        }
        
        hasUnsavedChanges = false;
    }
});

// Инициализация при загрузке
updateProjectNameVisibility();