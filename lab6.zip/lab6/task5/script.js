'use strict';

const loadImageBtn = document.getElementById('loadImageBtn');
const addToFavoritesBtn = document.getElementById('addToFavoritesBtn');
const currentImage = document.getElementById('currentImage');
const statusDiv = document.getElementById('statusMessage');
const favoritesGrid = document.getElementById('favoritesGrid');
const radioButtons = document.querySelectorAll('input[name="animalType"]');

const FAVORITES_STORAGE_KEY = 'favoritePets';

let currentImageUrl = null;

function getFormattedDateTime() {
    const now = new Date();
    return now.toLocaleString('ru-RU', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

function loadAndDisplayFavorites() {
    const favorites = JSON.parse(localStorage.getItem(FAVORITES_STORAGE_KEY)) || [];
    favoritesGrid.innerHTML = '';

    if (favorites.length === 0) {
        const noFavoritesItem = document.createElement('div');
        noFavoritesItem.className = 'no-favorites';
        noFavoritesItem.textContent = 'Избранное пусто';
        favoritesGrid.appendChild(noFavoritesItem);
        return;
    }

    favorites.forEach((item, index) => {
        const favoriteItem = document.createElement('div');
        favoriteItem.className = 'favorite-item';

        const img = document.createElement('img');
        img.src = item.url;
        img.alt = `Избранное ${index + 1}`;
        img.className = 'favorite-img';

        const info = document.createElement('div');
        info.className = 'favorite-info';
        info.textContent = item.date;

        const removeBtn = document.createElement('button');
        removeBtn.className = 'remove-favorite';
        removeBtn.textContent = '×';
        removeBtn.title = 'Удалить из избранного';
        removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (confirm('Удалить это изображение из избранного?')) {
                favorites.splice(index, 1);
                localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favorites));
                loadAndDisplayFavorites();
            }
        });

        favoriteItem.appendChild(img);
        favoriteItem.appendChild(info);
        favoriteItem.appendChild(removeBtn);

        favoritesGrid.appendChild(favoriteItem);
    });
}

function addToFavorites() {
    if (!currentImageUrl) return;

    const favorites = JSON.parse(localStorage.getItem(FAVORITES_STORAGE_KEY)) || [];
    const newFavorite = {
        url: currentImageUrl,
        date: getFormattedDateTime()
    };

    // Проверяем, нет ли уже такого изображения в избранном
    const isDuplicate = favorites.some(item => item.url === currentImageUrl);
    if (isDuplicate) {
        alert('Это изображение уже есть в избранном!');
        return;
    }

    favorites.unshift(newFavorite);

    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favorites));
    loadAndDisplayFavorites();
    statusDiv.textContent = 'Добавлено в избранное!';
}

async function loadImage() {
    const selectedAnimal = document.querySelector('input[name="animalType"]:checked').value;
    statusDiv.textContent = 'Загружается... (максимум 10 сек)';
    statusDiv.className = 'status-message';
    currentImage.style.display = 'none';
    currentImage.src = '';
    addToFavoritesBtn.disabled = true;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);

    let apiUrl = '';
    if (selectedAnimal === 'dog') {
        apiUrl = 'https://dog.ceo/api/breeds/image/random';
    } else if (selectedAnimal === 'cat') {
        apiUrl = 'https://api.thecatapi.com/v1/images/search';
    }

    try {
        const response = await fetch(apiUrl, {
            signal: controller.signal
        });

        clearTimeout(timer);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        let data;
        if (selectedAnimal === 'dog') {
            data = await response.json();
            currentImageUrl = data.message;
        } else if (selectedAnimal === 'cat') {
            data = await response.json();
            if (data && data.length > 0 && data[0].url) {
                currentImageUrl = data[0].url;
            } else {
                throw new Error('No image URL found in response');
            }
        }

        if (currentImageUrl) {
            const newImg = new Image();
            newImg.onload = () => {
                currentImage.src = newImg.src;
                currentImage.style.display = 'block';
                statusDiv.textContent = 'Готово!';
                addToFavoritesBtn.disabled = false;
            };
            newImg.onerror = () => {
                statusDiv.textContent = 'Не удалось загрузить картинку';
                statusDiv.className = 'status-message error-message';
            };
            newImg.src = currentImageUrl;
        } else {
            throw new Error('URL изображения не найден');
        }
    } catch (err) {
        clearTimeout(timer);

        if (err.name === 'AbortError') {
            statusDiv.textContent = 'Запрос отменён: время ожидания истекло.';
            statusDiv.className = 'status-message error-message';
        } else {
            console.error("Проблема с fetch:", err);
            statusDiv.textContent = 'Не удалось загрузить картинку';
            statusDiv.className = 'status-message error-message';
        }
        currentImageUrl = null;
        addToFavoritesBtn.disabled = true;
    }
}

loadImageBtn.addEventListener('click', loadImage);
addToFavoritesBtn.addEventListener('click', addToFavorites);

radioButtons.forEach(radio => {
    radio.addEventListener('change', () => {
        currentImage.style.display = 'none';
        currentImage.src = '';
        addToFavoritesBtn.disabled = true;
        statusDiv.textContent = 'Выберите тип животного и загрузите изображение';
        statusDiv.className = 'status-message';
    });
});

document.addEventListener('DOMContentLoaded', () => {
    loadAndDisplayFavorites();
});