'use strict';

const loadBtn = document.getElementById('loadCatBtn');
const statusDiv = document.getElementById('statusMessage');
const imgElement = document.getElementById('catImage');

async function loadRandomCat() {
    statusDiv.textContent = 'Загружается... (максимум 10 сек)';
    statusDiv.className = 'status-message';
    imgElement.style.display = 'none';
    imgElement.src = '';
    loadBtn.disabled = true;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);

    try {
        const response = await fetch('https://api.thecatapi.com/v1/images/search', {
            signal: controller.signal
        });

        clearTimeout(timer);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data && data.length > 0 && data[0].url) {
            // Создаём новый объект Image для проверки загрузки
            const newImg = new Image();
            
            newImg.onload = () => {
                // Передаём данные в основной элемент img
                imgElement.src = newImg.src;
                imgElement.style.display = 'block';
                statusDiv.textContent = 'Готово!';
            };
            
            newImg.onerror = () => {
                statusDiv.textContent = 'Не удалось загрузить картинку';
                statusDiv.className = 'status-message error-message';
            };
            
            newImg.src = data[0].url;
        } else {
            throw new Error('No image URL found in response');
        }
    } catch (err) {
        clearTimeout(timer);

        if (err.name === 'AbortError') {
            statusDiv.textContent = 'Запрос отменён: время ожидания истекло.';
            statusDiv.className = 'status-message error-message';
        } else {
            console.error("Проблема с fetch:", err);
            statusDiv.textContent = 'Не удалось загрузить картинку';
            statusDiv.className = 'status-message error-message';
        }
    } finally {
        loadBtn.disabled = false;
    }
}

loadBtn.addEventListener('click', loadRandomCat);

document.addEventListener('DOMContentLoaded', loadRandomCat);