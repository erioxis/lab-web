import Fastify from 'fastify';
import FastifyStatic from '@fastify/static';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const fastify = Fastify({ 
    logger: true 
});

// Регистрация статики
fastify.register(FastifyStatic, {
    root: path.join(__dirname, '../', 'public'),
});

// Регистрация маршрутов для lab7
import lab7Routes from './src/routes/lab7/index.js';
fastify.register(lab7Routes, { prefix: '/api/lab7' });

// Запуск сервера
const start = async () => {
    try {
        await fastify.listen({ port: 3000, host: '0.0.0.0' });
        console.log('Server is running on port 3000');
    } catch (err) {
        fastify.log.error(err);
        process.exit(1);
    }
};

start();