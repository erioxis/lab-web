export default async function routes(fastify, options) {
    // Главный endpoint
    fastify.get("/", async (request, reply) => {
        return {
            lab: "7",
            description: "Это главный API-эндпоинт для примеров Lab7."
        };
    });

    // Endpoint для hello
    fastify.get("/hello", async () => {
        return { message: "Привет! Сервер Fastify работает." };
    });

    // Endpoint для статуса
    fastify.get("/status", async (request, reply) => {
        await new Promise((resolve) => setTimeout(resolve, 1500));
        return { task: 1, status: "done", timestamp: new Date() };
    });

    // Калькулятор для 4 действий (+, -, *, /)
    fastify.get("/calc", async (request, reply) => {
        const { operation, a, b } = request.query;

        const numA = parseFloat(a);
        const numB = parseFloat(b);

        if (isNaN(numA) || isNaN(numB)) {
            reply.code(400);
            return { error: 'Параметры "a" и "b" должны быть числами' };
        }

        let result;
        switch (operation) {
            case "add":
                result = numA + numB;
                break;
            case "subtract":
                result = numA - numB;
                break;
            case "multiply":
                result = numA * numB;
                break;
            case "divide":
                if (numB === 0) {
                    reply.code(400);
                    return { error: 'Деление на ноль невозможно' };
                }
                result = numA / numB;
                break;
            default:
                reply.code(400);
                return { error: `Неизвестная операция: ${operation}` };
        }

        return { operation, a: numA, b: numB, result };
    });

    // Endpoint для создания инициалов
    fastify.get("/task2/makeInitials", async (request, reply) => {
        const { lastname, firstname, surname } = request.query;

        if (!lastname || !firstname || !surname) {
            reply.code(400);
            return { error: 'Все поля ФИО обязательны' };
        }

        return {
            lastname: lastname,
            firstnameLetter: firstname.charAt(0).toUpperCase(),
            surnameLetter: surname.charAt(0).toUpperCase()
        };
    });

    // Endpoint для статуса проекта
    fastify.get("/task2/makeProjectStatus", async (request, reply) => {
        const { lastname, firstname, surname, projectParticipant } = request.query;

        if (!lastname || !firstname || !surname) {
            reply.code(400);
            return { error: 'Все поля ФИО обязательны' };
        }

        return {
            lastname: lastname,
            firstnameLetter: firstname.charAt(0).toUpperCase(),
            surnameLetter: surname.charAt(0).toUpperCase(),
            projectParticipant: projectParticipant === 'true' ? 'Участвует' : 'Не участвует'
        };
    });
}